# 🐾 A Dog’s Life 3D / La vida de un perro 3D

Live a dog’s whole life, one story moment at a time. Pick a breed (including a brown Boston Terrier), name your dog, and make choices in 39 animated 3D scenes with talking characters. At the end you get a life score, a title and a life story.

Juega la vida entera de un perro, un momento a la vez. Elige una raza (incluido un Boston Terrier marrón), ponle nombre y toma decisiones en 39 escenas 3D animadas con personajes que hablan. Al final recibes un puntaje, un título y la historia de su vida.

- **English:** `index.html`
- **Español:** `es.html`

## Play
Open `index.html` (English) or `es.html` (Spanish) in a modern browser. No build step or install needed. Controls: click or press Space/Enter to advance dialogue, click to choose.

To host it for free, push this folder to GitHub and enable **Settings → Pages → Deploy from a branch (main, / root)**.

## Made for old hardware
Built to run on Intel HD 3000-class graphics: plain WebGL 1, no shadows maps, no anti-aliasing, fixed 1× resolution, merged grass geometry, procedural textures and a handful of cached materials. Realism comes from smooth low-poly shapes, sky gradients, fog, fake blob shadows and lots of animated life (butterflies, crabs, gulls, cars, pedestrians, rabbits, fireflies…).

## Files
| File | Purpose |
|---|---|
| `game.js` | Game engine, English texts and story data |
| `es.js` | Spanish translation (overrides the English texts) |
| `style.css` | Styles |
| `index.html` / `es.html` | English / Spanish entry points |

[three.js](https://threejs.org) r128 is loaded from cdnjs. Copy it into the repo and change the `<script>` tag if you want to work offline.

## Add a language
Copy `es.js`, translate the `U` strings, the `RP` replies and the `EV` list (same order as the story), then add a page like `es.html` that loads it after `game.js`.

## License
MIT. Written with the help of Claude (Anthropic).
