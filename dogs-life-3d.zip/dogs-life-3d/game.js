/* A Dog’s Life 3D — game.js (English base; es.js overrides texts). MIT License. */
var BR=[
{n:"Boston Terrier",t:"brown",c:"#7b4a2a",e:"#6a3d20",s:"#f6eee2",ear:"bat",blaze:1,life:13,b:{j:8,l:6}},
{n:"Labrador",c:"#e0b866",e:"#cfa24d",s:"#f0d79a",ear:"floppy",life:12,b:{j:8,h:4}},
{n:"Golden Retriever",c:"#d9993f",e:"#c4812a",s:"#ecc27e",ear:"floppy",life:11,b:{l:8,j:5}},
{n:"Pug",c:"#e6cfa4",e:"#3b2c22",s:"#3b2c22",ear:"bat",life:13,b:{j:6,m:8}},
{n:"Beagle",c:"#b8803f",e:"#5a3519",s:"#f6eee2",ear:"floppy",blaze:1,life:13,b:{m:8,b:4}},
{n:"Husky",c:"#8e98a6",e:"#5d6672",s:"#f4f6f8",ear:"point",blaze:1,life:13,b:{b:8,m:6}},
{n:"Corgi",c:"#d98a3d",e:"#c27428",s:"#fbf2e2",ear:"point",blaze:1,life:13,b:{j:6,b:6}},
{n:"German Shepherd",c:"#a9743a",e:"#2f2219",s:"#2f2219",ear:"point",life:11,b:{b:10,l:6}},
{n:"Dachshund",c:"#8a4a28",e:"#6e3a1e",s:"#a35c33",ear:"floppy",life:14,b:{b:6,m:4}},
{n:"Poodle",c:"#f1ebe0",e:"#e4dccb",s:"#f1ebe0",ear:"floppy",life:14,b:{h:6,j:4}},
{n:"Chihuahua",c:"#d8b78a",e:"#c59e6c",s:"#ecd5b0",ear:"bat",life:16,b:{b:-2,l:8,h:6}},
{n:"Border Collie",c:"#2b2724",e:"#2b2724",s:"#f6f2ea",ear:"point",blaze:1,life:13,b:{b:6,h:6}},
{n:"Bulldog",c:"#e7c9a0",e:"#b9875a",s:"#f3e1c4",ear:"bat",life:9,b:{l:8,h:-6}},
{n:"Mutt",t:"a mix of everything",c:"#a98a64",e:"#7d6446",s:"#e9dcc4",ear:"floppy",life:14,b:{h:6,m:4}}];
function dogSVG(b){var E=b.ear=="bat"?'<polygon points="20,52 26,10 54,36" fill="'+b.e+'"/><polygon points="100,52 94,10 66,36" fill="'+b.e+'"/>':b.ear=="point"?'<polygon points="22,54 30,8 54,34" fill="'+b.e+'"/><polygon points="98,54 90,8 66,34" fill="'+b.e+'"/>':'<ellipse cx="22" cy="64" rx="14" ry="29" fill="'+b.e+'"/><ellipse cx="98" cy="64" rx="14" ry="29" fill="'+b.e+'"/>';
return '<svg viewBox="0 0 120 120" aria-hidden="true">'+E+'<ellipse cx="60" cy="68" rx="38" ry="36" fill="'+b.c+'"/>'+(b.blaze?'<ellipse cx="60" cy="52" rx="6" ry="20" fill="#fff" opacity=".92"/>':'')+'<ellipse cx="60" cy="88" rx="21" ry="15" fill="'+b.s+'"/><circle cx="45" cy="64" r="6" fill="#1b1410"/><circle cx="75" cy="64" r="6" fill="#1b1410"/><circle cx="47" cy="62" r="2" fill="#fff"/><circle cx="77" cy="62" r="2" fill="#fff"/><ellipse cx="60" cy="80" rx="8" ry="5.5" fill="#1b1410"/><path d="M60 85 L60 91 M50 94 Q60 100 70 94" stroke="#1b1410" stroke-width="2.2" fill="none" stroke-linecap="round"/></svg>'}
// [stage, scene, text, [label, effects, result]...]  scenes: H home, P park, B beach, F forest, T town
var E=[
["p","H","A squeaky slipper lies by the sofa. Your human is out.",["Chew it to bits","m8j6","Stuffing everywhere!"],["Carry it to the door","l8","A slipper delivery!"],["Nap instead","h4","Growing time."]],
["p","H","Thunder rumbles outside.",["Hide under the bed","l2b-3","Dark and safe."],["Bark at the sky","b8m3","The thunder blinked first."],["Cuddle your human","l8j3","Warm hands."]],
["p","H","Dinner sits unattended on the counter.",["Steal a bite","m10j5h-4","Yum, then regret."],["Sit and beg","l4j2","A crumb for you."],["Walk away","h3l4","Willpower!"]],
["p","P","A butterfly drifts by on your first walk.",["Chase it","j8h2m2","So close!"],["Stay at heel","l6","Polite pup."],["Sniff everything","j5b3","So much news."]],
["p","P","A new puppy wants to play.",["Play together","j8b3","A new best friend."],["Hide behind your human","b-4l3","Maybe next time."],["Show who’s boss","m5b5l-2","Bold, but pushy."]],
["y","H","A squirrel taunts you from the fence.",["Leap the fence","b8m6h-3","Lost the squirrel, found a street."],["Bark from the yard","j3m2","A fierce warning."],["Ignore it","l4","Dignified."]],
["y","P","A muddy puddle after the rain.",["Jump in","j9m6","Bath day will be dramatic."],["Walk around","h2l3","Clean paws."],["Dig beside it","m8j4","Garden redesigned."]],
["y","P","A stick bigger than you lies on the path.",["Carry it home","j6b4","Pure pride."],["Fetch with a friend","j8l4","Great game."],["Chew it","h-2m4","Splinters."]],
["y","T","A bakery smell fills the street.",["Beg at the door","m5j5","The baker tosses you a roll."],["Stay by your human","l6","Good dog."],["Snatch a bag","m10h-3j4","Caught crumb-pawed."]],
["y","T","A loud truck rumbles past.",["Bark at it","b5m3","It ignored you."],["Stand firm","b8","Steady as a rock."],["Hide behind your human","l5b-3","Safe."]],
["y","F","A mossy path leads into dark trees.",["Explore ahead","b8j5","You found something shiny."],["Stay close","l5h2","Safe and sound."],["Howl","m5j4","The echo howls back!"]],
["y","F","A hedgehog curls up in your way.",["Sniff it","h-3j4","Ouch, spiky!"],["Guard it","l3b5","Kind heart."],["Go around","h2","Wise."]],
["a","H","Your human is sad on the couch.",["Rest your head in their lap","l10j3","A smile at last."],["Bring a toy","l5j4","The soggy rope helps."],["Zoomies","j6m4","Ridiculous, effective."]],
["a","H","Someone knocks at the door at night.",["Bark to alert","l6b5","On duty."],["Greet with wags","j4l-1","A friendly courier."],["Hide","b-5","Braver tomorrow."]],
["a","P","The dog park is full of friends.",["Join the game","j8h3","Tag, you’re it!"],["Watch from a bench","l4","Observing."],["Steal a ball","m8j5","Ball thief!"]],
["a","P","A kid drops an ice cream cone.",["Lick it up","j8h-2m3","Brain freeze!"],["Return it to the kid","l6","Hero."],["Ignore it","h2","Self-control."]],
["a","P","A duck waddles by the pond.",["Chase it","j6m5b2","Quack attack!"],["Make friends","j4l3","An odd friendship."],["Stare it down","b3","Intense."]],
["a","B","Beach day. The waves are huge.",["Swim out","b8j8h3","Salt, sun, joy."],["Dig in the sand","j6m3","A whole fort."],["Nap in the shade","h4","Sandy snooze."]],
["a","B","A seagull steals your human’s sandwich.",["Chase the gull","b6j6","Victory!"],["Bark helplessly","j2","At least you tried."],["Share what’s left","l5","Crumbs of love."]],
["a","B","A tide pool glitters with little crabs.",["Sniff them","j5h-3","Pinched nose!"],["Dig a trench","m4j4","Crab condo."],["Watch patiently","b3h2","Patient hunter."]],
["a","B","A lost child cries near the lifeguard tower.",["Lead them to the lifeguard","l8b8","Beach hero!"],["Bark for help","b6l5","Everyone came."],["Run away","b-6","You were scared."]],
["a","F","Your human offers a long hike.",["Go all the way","h8j6b3","You sleep like a log."],["Turn back early","h2","Cozy."],["Wander off the trail","b8m6h-3","An adventure!"]],
["a","F","A noise rustles near the campfire at night.",["Bark and charge","b10l6h-4","Just the wind."],["Wake your human","l8","Teamwork."],["Keep sleeping","h3","Someone else’s problem."]],
["a","F","A stream blocks the trail.",["Leap across","b6h-2","Splash!"],["Wade through","j6h1","Cool paws."],["Wait for help","l5","Carried across."]],
["a","F","A lost kitten shivers under a log.",["Guard it","l6b6j3","Hero of the woods."],["Chase it away","m5l-4","The kitten is not impressed."],["Share your bed","j6l6","New friends."]],
["a","T","The family brings home a new baby.",["Be a gentle guardian","l10j3","You watch the crib every night."],["Chew shoes in protest","m8l-3","Expensive."],["Keep your distance","l2","Still deciding."]],
["a","T","A street musician plays a wild tune.",["Howl along","j8m4","Encore!"],["Sit and listen","l3j4","Soothing."],["Run in circles","j6m3","Dance party."]],
["a","T","The mail carrier approaches the gate.",["Bark ferociously","b5m4","Mission: protect!"],["Wag and wait","j4l3","Treat time."],["Hide","b-4","Not today."]],
["a","T","A fancy cat sneers from a windowsill.",["Bark at it","m6b3","Window war."],["Ignore it","l3h2","Above it all."],["Play dead","j3m3","Dramatic."]],
["s","H","Your knees creak on the stairs.",["Keep climbing","h-4b4","Stubborn."],["Ask to be carried","l5h2","Gladly."],["Move your bed downstairs","h4","Smart."]],
["s","H","A new puppy joins the household.",["Mentor it","l8j5","You teach all the tricks."],["Grumble","m4j-2","Get off my lawn."],["Ignore it politely","h2","Peace."]],
["s","H","You find your old favorite toy under the couch.",["Play with it","j10","Still squeaks!"],["Nap with it","j5h3","A cozy memory."],["Hide it","m3j3","Old habits."]],
["s","P","The bench by the pond is empty.",["Lie in the sun","h4j4","Warm."],["Visit old friends","j6l3","Tails wag."],["Watch the ducks","j4b2","Peaceful."]],
["s","P","The old tree you once dug under still stands.",["Sniff the roots","j5","Memories."],["Dig once more","m4h-3j5","Old paws still go."],["Sit beneath it","l4h2","Shady."]],
["s","B","A quiet evening at the shore.",["Walk the tideline","h3j6","Soft sand."],["Sit with your human","l10j4","Together."],["Bark at the waves","b3j4","Still got it."]],
["s","T","A stranger’s child asks to pet you.",["Accept pats","j8l3","Bliss."],["Lean in","l5j5","Hello, friend."],["Retreat","h2","Tired."]],
["s","T","The bakery door is open again.",["Beg gently","j6","One more roll."],["Sit calmly","l5h2","Dignified."],["Sneak a bite","m6j4h-2","Still sneaky."]],
["s","H","Sunset on the porch with your human.",["Lean in close","l10j6","No words needed."],["Watch the street","b2j3","All quiet."],["Doze off","h4","Warm."]],
["s","H","You feel very tired tonight. Your human sits beside you.",["Stay close","l10j4","Their hand is steady."],["One last zoomie","j8h-4","What a show!"],["Rest your head","h4","Easy breathing."]]];

var D=[
["","*","A squeaky slipper… and nobody’s home. Tempting."],["H","H","Shh, it’s just thunder, little one. I’m here."],["H","H","Dinner’s almost ready. Don’t you dare touch that!"],["HR","H","Look, your first walk! Isn’t the world big?"],["P","P","Hey! Wanna play? I’m new here too!"],
["SH","S","Nyah nyah! Can’t catch me, floof!"],["H","H","Careful, it rained all night. Mud everywhere."],["P","P","That stick is huge! Bet you can’t carry it."],["BH","B","Fresh rolls! Smells good, doesn’t it, little pup?"],["H","H","Easy… it’s only a truck. Stay with me."],["H","H","The forest looks spooky, but I’ll be right behind you."],["E","E","Please don’t sniff me. I’m very prickly."],
["H","H","Hard day at work… I just feel a little blue."],["H","H","Did you hear that? Someone’s at the door."],["PKJ","K","Can your dog play too? We’re starting a game!"],["KHW","K","Oh no! My ice cream!"],["DH","D","Quack. This is MY pond, pup."],["HK","H","Look at those waves! Ready for a swim?"],["HG","G","Squawk! Thanks for the sandwich!"],["H","H","See the tiny crabs? Be gentle."],["KL","K","I can’t find my mom… sniff…"],["H","H","Long hike today. Think you can keep up?"],["H","H","What was that noise? Stay close, buddy."],["H","H","The bridge washed out. How do we get across?"],["C","C","Mew… I’m lost and cold…"],["HAW","H","Meet the baby! Be gentle, okay?"],["UKW","U","La la la! Anyone want a song?"],["MH","M","Package for you! Is your dog friendly?"],["CH","C","Hmph. Another dog. How tedious."],
["H","H","Oh, old friend, those stairs are getting tough."],["HP","H","Say hello. This puppy will live with us now."],["H","H","Look what I found under the couch!"],["H","H","Let’s sit by the pond like we used to."],["HR","H","Remember digging under this tree?"],["H","H","The sea looks beautiful tonight."],["KH","K","Can I pet your dog? He looks so nice."],["BH","B","Hello again, old friend! Smells good, hm?"],["H","H","Another sunset together. I love these."],["H","H","You’re tired, aren’t you? I’m right here."]];

var RP={H:["That’s my good dog!","Oh, you little troublemaker!","It’s okay, I’ve got you."],K:["Yay! You’re the best!","Hehe, so silly!","Aww, don’t be scared!"],P:["Woof! You’re fun!","Ha! Wanna race?","Okay, okay, no worries."],C:["…Fine. You’re tolerable.","Hiss! How rude!","Scaredy-dog. Ha."],S:["Whoa, you’re fast!","Missed me again!","Eek! Hide!"],D:["Quack! Not bad, pup.","QUACK! Out of my pond!","Quack?! Don’t splash!"],G:["Squawk! Nice moves!","Squawk! Mine now!","Squawk! Run!"],B:["Good dog! Here’s a roll.","Hey! That’s for paying customers!","Easy, nobody’s mad."],M:["Good boy! Here’s a treat.","Whoa! Easy there!","Don’t worry, I’m leaving."],U:["Wonderful! A natural.","Ha! Great duet!","Don’t be shy, friend."],A:["Gah! Goo!","Ha ha ha!","Wah…"],E:["Thank you, kind pup.","Ouch! Prickly warning!","Phew, scary!"],L:["Great job, hero!","Easy, buddy!","It’s okay, stay near."],R:["How kind you are!","Ha! You can’t catch me!","Eek! You scared me!"],W:["What a good doggy!","Oh, you rascal!","Oh, poor thing, come here."],J:["Nice pace, champ!","Hey, watch it!","Easy, I’m just jogging!"]};

/* ===== Localisable UI strings (English default; es.js overrides) ===== */
var U={title:"A Dog’s Life 3D",pick:"Choose your dog breed. You will live their whole life, moment by moment.",name:"Name your dog",ph:"Type a name...",begin:"Begin the life",back:"Back to breeds",
wait:function(b,t){return"A "+(t?t+" ":"")+b+" puppy is waiting."},nogl:"3D not available",noglt:"Your browser could not start WebGL. Try updating your graphics driver or browser.",def:"Buddy",
born:function(b,n){return"Born a "+b+" puppy named "+n+"."},mom:function(i,n){return"Moment "+i+" of "+n},age:"Age",ask:"What do you do?",cont:"▸ Click or press Space",think:"(thinking)",
pass:"passed peacefully",sur:function(b,a){return"A "+b+", age "+a+". Surrounded by love."},score:"Life score",story:"Life story",again:"Live another dog’s life",q:["“","”"],
K:{h:"Health",j:"Joy",l:"Loyalty",m:"Mischief",b:"Bravery"},pop:{zoom:"💨 Zoomies!",bark:"WOOF!",nuzzle:"💕",nap:"💤",spin:"🌀",hop:"✨",cower:"😨"},
ti:["A Very Good Dog","Legendary Troublemaker","Loyal Legend","Fearless Hero","Pure Joy","Picture of Health","Perfect Gentledog"],bh:["mischievous","playful","well-behaved"],
sum:function(n,bh,l,b,j){return n+" was a "+bh+" dog who "+(l?"loved their family deeply":"lived life on their own terms")+(b?", faced the world bravely":"")+(j?" and spread joy wherever they went.":" and had a quiet, gentle life.")},
NM:{H:"Your human",K:"Kid",P:"Puppy",C:"Cat",S:"Squirrel",D:"Duck",G:"Seagull",B:"Baker",M:"Mail carrier",U:"Musician",A:"Baby",E:"Hedgehog",L:"Lifeguard",R:"Rabbit",W:"Grandma",J:"Jogger"},
STG:{p:"Puppyhood",y:"Young dog",a:"Adult years",s:"Golden years"},SCN:{H:"Home yard",P:"Park",B:"Beach",F:"Forest",T:"Town"},BN:null};

/* ===== Story order, scenes ===== */
var N=E.length;
var ORD=[0,3,1,4,2, 5,8,6,10,9,7,11, 12,14,17,21,26,13,18,23,27,15,19,22,28,16,24,20,25, 29,32,30,34,35,33,31,36,37,38];
var SC={H:{g:0x6fb04a,k:0xbfe3f5},P:{g:0x5fa845,k:0xcfe8f5},B:{g:0xe8d49a,k:0xcfeaf5},F:{g:0x3f7a3a,k:0xa9c8b0},T:{g:0x8d8d92,k:0xd5e0ea}};
var $=function(i){return document.getElementById(i)};
var cl=function(v){return Math.max(0,Math.min(100,Math.round(v)))};
var esc=function(s){return s.replace(/[&<>"]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})};
var T=window.THREE,rd,sc,cam,W,dg,legs=[],tail,HL,DL,clk,adv=null,S={},go=0,chars=[],amb=[],ap=null,spk="",cr=12,ct=12,MC={},SG,SM,CM;
function age(){return S.turn*S.br.life/N}
function bars(){var h="";for(var k in U.K)h+='<div class="stat"><span>'+U.K[k]+'</span><div class="bar"><i style="width:'+S[k]+'%"></i></div></div>';return h}
function start(){go=0;$("game").style.display="none";$("app").style.display="block";
 if(U.BN)BR.forEach(function(b,i){b.n=U.BN[i][0];b.t=U.BN[i][1]});
 var h='<h1>🐾 '+U.title+'</h1><p class="sub">'+U.pick+'</p><div class="grid">';
 BR.forEach(function(b,i){h+='<button class="card" onclick="pickBreed('+i+')">'+dogSVG(b)+'<b>'+b.n+'</b><small>'+(b.t||"")+'</small></button>'});
 $("app").innerHTML=h+'</div>';scrollTo(0,0)}
function pickBreed(i){var b=BR[i];
 S={br:b,bi:i,name:"",h:50,j:50,l:50,m:20,b:40,turn:0,i:0,log:[]};
 for(var k in b.b)S[k]=cl(S[k]+b.b[k]);
 $("app").innerHTML='<h1>'+U.name+'</h1><div class="center">'+dogSVG(b).replace("<svg",'<svg style="width:150px;height:150px"')+'<p class="sub">'+U.wait(b.n,b.t)+'</p></div><div class="panel"><input id="nm" maxlength="16" placeholder="'+U.ph+'" autocomplete="off"><button class="btn go" onclick="begin()">'+U.begin+'</button><button class="btn" onclick="start()">'+U.back+'</button></div>';
 $("nm").focus();$("nm").onkeydown=function(e){if(e.key=="Enter")begin()}}
function begin(){
 if(!T||!initGL()){$("app").innerHTML='<h1>'+U.nogl+'</h1><p class="sub">'+U.noglt+'</p><button class="btn go" onclick="start()">'+U.back+'</button>';return}
 S.name=$("nm").value.trim()||U.def;S.log.push([0,U.born(S.br.n,S.name)]);
 $("app").style.display="none";$("game").style.display="block";makeDog();go=1;clk.getDelta();moment()}

/* ===== 3D helpers (smooth low-poly, light on GPU) ===== */
function mat(c){return MC[c]||(MC[c]=new T.MeshLambertMaterial({color:c}))}
function hx(s){return parseInt(s.slice(1),16)}
function put(p,m,x,y,z){m.position.set(x,y,z);p.add(m);return m}
function bx(p,w,h,d,c,x,y,z){return put(p,new T.Mesh(new T.BoxGeometry(w,h,d),mat(c)),x,y,z)}
function sp(p,r,c,x,y,z,sx,sy,sz){var m=put(p,new T.Mesh(new T.SphereGeometry(r,10,8),mat(c)),x,y,z);m.scale.set(sx||1,sy||1,sz||1);return m}
function cy(p,a,b,h,c,x,y,z){return put(p,new T.Mesh(new T.CylinderGeometry(a,b,h,8),mat(c)),x,y,z)}
function co(p,r,h,c,x,y,z){return put(p,new T.Mesh(new T.ConeGeometry(r,h,6),mat(c)),x,y,z)}
function shad(g,r){if(!SG){SG=new T.CircleGeometry(1,12);SG.rotateX(-Math.PI/2);SM=new T.MeshBasicMaterial({color:0,transparent:true,opacity:.28,depthWrite:false})}var m=new T.Mesh(SG,SM);m.scale.set(r,1,r);m.position.y=.03;g.add(m)}
function makeDog(){var b=S.br,c=hx(b.c),e=hx(b.e),s=hx(b.s),fl=[0,3,12].indexOf(S.bi)>=0;
 if(dg)sc.remove(dg);dg=new T.Group();legs=[];
 sp(dg,.62,c,0,1.4,0,1,.9,1.7);sp(dg,.5,c,0,1.7,.9,1,1,1.2);sp(dg,.5,c,0,2,1.25,1,.95,1);
 sp(dg,.28,s,0,1.85,fl?1.65:1.8,.85,.75,fl?.9:1.4);sp(dg,.09,0x111111,0,1.95,fl?1.98:2.25);
 [-1,1].forEach(function(k){sp(dg,.1,0xffffff,k*.22,2.15,1.68);sp(dg,.06,0x111111,k*.22,2.15,1.76);
  if(b.ear=="floppy")sp(dg,.2,e,k*.5,1.95,1.2,.5,1.6,1);else{var r=co(dg,.22,.7,e,k*.3,2.6,1.1);r.rotation.z=-k*.2}});
 if(b.blaze){sp(dg,.12,0xffffff,0,2.25,1.62,.7,2.4,.6);sp(dg,.3,0xffffff,0,1.35,1.05,1,1.3,.6)}
 tail=new T.Group();tail.position.set(0,1.75,-1.15);cy(tail,.06,.13,.9,c,0,.3,-.3).rotation.x=-.9;dg.add(tail);
 [[-.38,.8],[.38,.8],[-.38,-.8],[.38,-.8]].forEach(function(p){var g=new T.Group();g.position.set(p[0],1,p[1]);cy(g,.13,.11,1,c,0,-.5,0);sp(g,.17,s,0,-.97,.05,1,.6,1.3);dg.add(g);legs.push(g)});
 shad(dg,1.6);sc.add(dg)}
function person(sh,hr,s,sk,x){var g=new T.Group();sk=sk||0xf0c8a0;
 cy(g,.42,.5,1.2,sh,0,1.6,0);sp(g,.4,sk,0,2.5,0);sp(g,.43,hr,0,2.62,-.06,1,.75,1);sp(g,.05,0x222222,-.15,2.52,.36);sp(g,.05,0x222222,.15,2.52,.36);
 g.userData.arm=[];[-1,1].forEach(function(k){var a=new T.Group();a.position.set(k*.58,2.05,0);cy(a,.11,.09,.9,sh,0,-.4,0);sp(a,.12,sk,0,-.9,0);g.add(a);g.userData.arm.push(a);cy(g,.17,.14,1,0x3b4a6b,k*.22,.5,0);bx(g,.3,.15,.5,0x222222,k*.22,.08,.08)});
 if(x)x(g);shad(g,.9);g.scale.setScalar(s);return g}
function animal(c,d,s,k){var g=new T.Group();
 sp(g,.45,c,0,.8,0,1,.9,1.5);sp(g,.32,c,0,1.2,.75);sp(g,.06,0x111111,-.14,1.3,1.02);sp(g,.06,0x111111,.14,1.3,1.02);
 [[-.22,.4],[.22,.4],[-.22,-.4],[.22,-.4]].forEach(function(p){cy(g,.08,.07,.5,d,p[0],.25,p[1])});
 [-1,1].forEach(function(q){
  if(k=="P")sp(g,.15,d,q*.3,1.2,.7,.5,1.4,1);
  if(k=="C"||k=="S")co(g,.1,.3,k=="C"?c:d,q*.17,1.55,.7);
  if(k=="R")sp(g,.1,c,q*.12,1.85,.7,.6,3,.5);
  if(k=="G")sp(g,.4,0xaaaaaa,q*.4,.9,0,.3,.9,1.2)});
 if(k=="P"||k=="C")cy(g,.05,.08,1,c,0,1.1,-1).rotation.x=-1.1;
 if(k=="S")sp(g,.35,d,0,1.2,-.9,.7,1.8,.8);
 if(k=="R")sp(g,.15,0xffffff,0,.8,-.75);
 if(k=="D"||k=="G"){co(g,.1,.3,k=="D"?0xe8892b:0xf2c14a,0,1.15,1.1).rotation.x=Math.PI/2}
 if(k=="E")for(var i=0;i<10;i++)co(g,.1,.4,d,Math.cos(i)*.3,1.2,-.5+Math.sin(i*2)*.5);
 shad(g,.9);g.scale.setScalar(s);return g}
function mk(c){var g,sk=[0xf0c8a0,0xc68c5a,0x8d5a3a];
 if(c=="H")g=person(0x4a90d9,0x4a3020,1);
 else if(c=="K")g=person(0xf2b84b,0x2b1d12,.6);
 else if(c=="B")g=person(0xffffff,0xffffff,1,0,function(g){bx(g,.7,.7,.7,0xffffff,0,3.1,0)});
 else if(c=="M")g=person(0x2f5aa8,0x2f5aa8,1);
 else if(c=="L")g=person(0xe03c3c,0xe8d24a,1,0xc68c5a);
 else if(c=="U")g=person(0x8a4fb0,0x222222,1,0x8d5a3a,function(g){bx(g,.9,.7,.2,0xc98a3a,.4,1.4,.4)});
 else if(c=="A")g=person(0xffd6e0,0xf5e6c8,.45);
 else if(c=="W")g=person(0x9b6fb5,0xdddddd,.92);
 else if(c=="J")g=person(0xe03c3c,0x222222,1,0xc68c5a);
 else{var a={P:[0xd9a066,0x8a5a2b,.8],C:[0x9a9a9a,0x6d6d6d,.65],S:[0x9b6a3c,0xc4894a,.5],D:[0xf2d03b,0xe8892b,.55],G:[0xf4f4f4,0xaaaaaa,.65],E:[0x5a4632,0x3d2e1f,.5],R:[0xd8c9b0,0xb59e7a,.6]}[c];g=animal(a[0],a[1],a[2],c)}
 g.userData.c=c;return g}
function cast(s){chars.forEach(function(q){sc.remove(q)});chars=[];var n=s.length;
 for(var i=0;i<n;i++){var a=n==1?0:(i/(n-1)-.5)*1.8,x=Math.sin(a)*6,z=Math.cos(a)*6,g=mk(s[i]);g.position.set(x,0,z);g.rotation.y=Math.atan2(-x,-z);g.userData.hop=0;sc.add(g);chars.push(g)}}
function initGL(){if(rd)return 1;
 try{rd=new T.WebGLRenderer({antialias:false});if(!rd.getContext())return 0}catch(e){return 0}
 rd.setPixelRatio(1);rd.setSize(innerWidth,innerHeight);$("gl").appendChild(rd.domElement);
 sc=new T.Scene();cam=new T.PerspectiveCamera(50,innerWidth/innerHeight,.1,220);
 HL=new T.HemisphereLight(0xffffff,0x6a7a55,.8);sc.add(HL);DL=new T.DirectionalLight(0xfffbe8,.55);DL.position.set(10,20,8);sc.add(DL);
 CM=new T.MeshBasicMaterial({color:0xffffff,fog:false,transparent:true,opacity:.9});
 W=new T.Group();sc.add(W);clk=new T.Clock();
 addEventListener("resize",function(){rd.setSize(innerWidth,innerHeight);cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix()});
 var nx=function(){if(adv){var f=adv;adv=null;f()}};
 $("dlg").onclick=function(e){if(e.target.tagName!="BUTTON")nx()};
 addEventListener("keydown",function(e){if(e.key==" "||e.key=="Enter"){if(adv)e.preventDefault();nx()}});
 loop();return 1}

/* ===== Environment: procedural textures, sky, merged grass ===== */
function gtex(col){var c=document.createElement("canvas");c.width=c.height=64;var x=c.getContext("2d");x.fillStyle="#"+new T.Color(col).getHexString();x.fillRect(0,0,64,64);
 for(var i=0;i<260;i++){var v=Math.random()*40-20;x.fillStyle="rgba("+(v>0?"255,255,255":"0,0,0")+","+Math.abs(v)/160+")";x.fillRect(Math.random()*64,Math.random()*64,2,2)}
 var t=new T.CanvasTexture(c);t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(30,30);return t}
function ftex(col){var c=document.createElement("canvas");c.width=64;c.height=128;var x=c.getContext("2d");x.fillStyle="#"+new T.Color(col).getHexString();x.fillRect(0,0,64,128);
 for(var i=0;i<4;i++)for(var j=0;j<3;j++){x.fillStyle=(i+j)%3?"#9fd0e8":"#ffe9a0";x.fillRect(8+j*18,8+i*30,12,18)}return new T.CanvasTexture(c)}
function sky(top,bot){var g=new T.SphereGeometry(100,12,8),c=[],p=g.attributes.position,a=new T.Color(top),b=new T.Color(bot),k=new T.Color();
 for(var i=0;i<p.count;i++){k.copy(b).lerp(a,Math.max(0,p.getY(i)/100));c.push(k.r,k.g,k.b)}
 g.setAttribute("color",new T.Float32BufferAttribute(c,3));return new T.Mesh(g,new T.MeshBasicMaterial({vertexColors:true,side:T.BackSide,fog:false}))}
function tufts(n,a,b,c1,c2){var p=[],k=[],A=new T.Color(c1),B=new T.Color(c2);
 for(var i=0;i<n;i++){var an=Math.random()*6.283,r=a+Math.random()*(b-a),x=Math.cos(an)*r,z=Math.sin(an)*r,h=.4+Math.random()*.5,c=Math.random()<.5?A:B;
  for(var j=0;j<3;j++){var q=j*2.1+Math.random(),dx=Math.cos(q)*.12,dz=Math.sin(q)*.12;p.push(x-dx,0,z-dz,x+dx,0,z+dz,x,h,z);for(var m=0;m<3;m++)k.push(c.r,c.g,c.b)}}
 var g=new T.BufferGeometry();g.setAttribute("position",new T.Float32BufferAttribute(p,3));g.setAttribute("color",new T.Float32BufferAttribute(k,3));
 W.add(new T.Mesh(g,new T.MeshBasicMaterial({vertexColors:true,side:T.DoubleSide})))}
function tree(x,z,s,pine,c){cy(W,.2*s,.3*s,2*s,0x6b4423,x,s,z);var col=c||[0x2f7d32,0x3d8f3a,0x4a9c40][Math.floor(Math.random()*3)];
 if(pine){for(var i=0;i<3;i++)co(W,(2.1-i*.5)*s,2.2*s,col,x,(2.8+i*1.3)*s,z)}
 else{sp(W,1.6*s,col,x,3.6*s,z,1,.9,1);sp(W,1.1*s,col,x+.8*s,3.2*s,z+.4*s);sp(W,1.1*s,col,x-.8*s,3.3*s,z-.3*s)}}
function ring(n,a,b,f){for(var i=0;i<n;i++){var an=Math.random()*6.283,r=a+Math.random()*(b-a);f(Math.cos(an)*r,Math.sin(an)*r)}}
function bld(x,z,w,h,d,col){var m=new T.Mesh(new T.BoxGeometry(w,h,d),new T.MeshLambertMaterial({map:ftex(col)}));return put(W,m,x,h/2,z)}
function bench(x,z,r){var g=new T.Group();bx(g,3,.2,1,0x8a5a2b,0,.6,0);bx(g,3,.8,.15,0x8a5a2b,0,1.1,-.5);bx(g,.2,.6,.8,0x444444,-1.2,.3,0);bx(g,.2,.6,.8,0x444444,1.2,.3,0);g.position.set(x,0,z);g.rotation.y=r||0;W.add(g)}
function lamp(x,z){cy(W,.1,.12,5,0x333333,x,2.5,z);sp(W,.4,0xffe9a0,x,5.2,z).material=new T.MeshBasicMaterial({color:0xffe9a0})}
function car(c){var g=new T.Group();bx(g,4,1,2,c,0,.9,0);bx(g,2.2,.9,1.8,0xcfe6f0,-.3,1.8,0);[[-1.3,1],[1.3,1],[-1.3,-1],[1.3,-1]].forEach(function(p){cy(g,.45,.45,.3,0x222222,p[0],.45,p[1]).rotation.x=Math.PI/2});return g}
function build(id,st){var s=SC[id],i,su=st=="s",hz=su?0xf5b07a:s.k;
 while(W.children.length)W.remove(W.children[0]);
 W.add(sky(su?0x4a5a9a:0x5fb4ec,hz));
 var sn=new T.Mesh(new T.SphereGeometry(4,10,8),new T.MeshBasicMaterial({color:su?0xffb060:0xfff3b0,fog:false}));sn.position.set(30,su?14:40,-55);W.add(sn);
 sc.fog=new T.Fog(hz,30,id=="F"?48:95);HL.color.set(su?0xffd9b0:0xffffff);DL.color.set(su?0xffb070:0xfffbe8);
 var gm=new T.Mesh(new T.PlaneGeometry(200,200),new T.MeshLambertMaterial({map:gtex(s.g)}));gm.rotation.x=-Math.PI/2;W.add(gm);
 if(id!="B"&&id!="T")tufts(id=="F"?500:380,3,40,id=="F"?0x2b6a2e:0x4a9a3a,id=="F"?0x1f5224:0x5fb04a);
 if(id=="H"){bx(W,10,6,8,0xe0c4a0,-12,3,-16);co(W,8,4,0xb5513a,-12,8,-16).rotation.y=Math.PI/4;bx(W,1.6,2.8,.1,0x7a4a2a,-10,1.4,-11.95);bx(W,1.4,1.4,.1,0x9fd0e8,-15,3.5,-11.95);bx(W,1,3,1,0x9a5a4a,-8,8,-17);
  bx(W,60,.2,.2,0xffffff,0,1.6,26);bx(W,60,.2,.2,0xffffff,0,.8,26);for(i=-30;i<=30;i+=3)bx(W,.3,2,.3,0xffffff,i,1,26);
  bx(W,2.4,1.6,2.4,0xb5513a,9,.8,-12);co(W,2,1.2,0x7a3a2a,9,2.2,-12).rotation.y=Math.PI/4;
  ring(5,13,26,function(x,z){tree(x,z,1+Math.random()*.5)});ring(20,5,14,function(x,z){sp(W,.18,[0xff6f91,0xffd23f,0xffffff,0xc77dff][Math.floor(Math.random()*4)],x,.3,z)})}
 if(id=="P"){cy(W,7,7,.2,0x4aa3d8,13,.05,-9);for(i=0;i<4;i++)cy(W,.6,.6,.05,0x3d8f3a,10+i*2,.18,-8-i);bench(-9,-6,.4);bench(9,10,-2.4);lamp(-4,-12);lamp(14,6);
  bx(W,3,.05,3,0xd94a4a,-6,.05,8);bx(W,.6,.4,.5,0x9a6a3a,-5.5,.3,8.4);ring(10,12,32,function(x,z){tree(x,z,1+Math.random()*.6)});ring(24,5,18,function(x,z){sp(W,.18,[0xff6f91,0xffd23f,0xffffff][Math.floor(Math.random()*3)],x,.3,z)})}
 if(id=="B"){bx(W,200,.3,50,0x2f9fd8,0,.05,-45);bx(W,200,.1,.8,0xffffff,0,.25,-19.5);
  cy(W,.1,.1,4,0x8a6a3a,-8,2,-8);co(W,3,1.4,0xe03c3c,-8,4.3,-8);bx(W,2.5,.05,1.2,0xffd23f,-6,.05,-6);
  ring(6,10,26,function(x,z){if(z<-14)return;cy(W,.2,.3,5,0x7a5a30,x,2.5,z);for(var j=0;j<4;j++)sp(W,1.6,0x3d9a3a,x+Math.cos(j*1.6)*1.2,5.4,z+Math.sin(j*1.6)*1.2,1,.3,.5)});
  ring(6,9,20,function(x,z){if(z>-14)sp(W,1.3,0x8a8a8a,x,.5,z,1,.7,1)})}
 if(id=="F"){ring(44,9,36,function(x,z){tree(x,z,1+Math.random()*.9,1,[0x24602b,0x1e5028,0x2c6a30][Math.floor(Math.random()*3)])});
  ring(4,6,16,function(x,z){cy(W,.35,.35,3.5,0x5a3d20,x,.35,z).rotation.z=Math.PI/2});
  ring(8,5,16,function(x,z){cy(W,.1,.12,.5,0xf0e6d0,x,.25,z);sp(W,.3,0xd94a4a,x,.55,z,1,.6,1)});ring(5,8,22,function(x,z){sp(W,1.3,0x7a7a7a,x,.5,z,1,.7,1)})}
 if(id=="T"){bx(W,200,.05,9,0x3a3a40,0,.03,-12);for(i=-50;i<=50;i+=8)bx(W,3,.06,.3,0xffffff,i,.07,-12);bx(W,200,.2,4,0xbdbdbd,0,.1,-5.5);bx(W,200,.2,4,0xbdbdbd,0,.1,-18.5);
  var cs=[0xc9a27e,0xb8c4d4,0xd98e8e,0xe6d9a8,0x9fc2a0];for(i=-48;i<=48;i+=12){bld(i,-30,10,8+Math.random()*10,8,cs[Math.floor(Math.random()*5)]);bld(i,30,10,7+Math.random()*9,8,cs[Math.floor(Math.random()*5)])}
  for(i=-30;i<=30;i+=15)lamp(i,-7);bench(-8,-7.5,0);tree(6,-7,.6);tree(-20,-7,.6);bx(W,5,.2,2.4,0xd94a4a,2,3.4,-26)}}
function A(g,u){g.userData=u;W.add(g);amb.push(g);return g}
function ped(i,x,z,R,k){var g=person([0xd9534f,0x5cb85c,0xf0ad4e,0x9b59b6,0x39a0c8][i%5],[0x333333,0x6b4a2a,0xb08040][i%3],.95,[0xf0c8a0,0xc68c5a,0x8d5a3a][i%3]);g.position.set(x,0,z);return A(g,{k:k||"w",x0:x,z0:z,R:R,a:i})}
function ambient(id){amb=[];var i,g;
 for(i=0;i<4;i++){g=sp(W,1,0xffffff,0,30,-30+i*20,3,.6,1.6);g.material=CM;A(g,{k:"cl",x0:i*40-60})}
 if(id=="H"||id=="P")for(i=0;i<6;i++)A(bx(W,.3,.05,.5,[0xffd23f,0xff6f91,0xffffff][i%3],0,3,0),{k:"b",a:i*1.3,r:8+i*2});
 if(id=="H")for(i=0;i<4;i++)A(sp(W,.25,0x7a6a5a,-6+i*4,2,25.5),{k:"pg",a:i});
 if(id=="P"){ped(0,-18,-18,10);ped(1,16,18,8);ped(2,0,-24,14,"r");g=mk("K");g.position.set(10,0,16);A(g,{k:"r",x0:10,z0:16,R:5,a:1});g=mk("P");g.position.set(-14,0,14);A(g,{k:"w",x0:-14,z0:14,R:6,a:2});A(sp(W,.5,0xffd23f,0,1,0),{k:"ball",x0:12,z0:16})}
 if(id=="B"){for(i=0;i<4;i++)A(bx(W,.6,.3,.4,0xe0502e,-10+i*6,.2,-8-(i%2)*3),{k:"c",x0:-10+i*6,a:i});
  for(i=0;i<3;i++)A(sp(W,.3,0xffffff,0,0,0,1,.5,2),{k:"f",a:i*2.1,r:14+i*3,h:10+i*2});
  g=person(0xe0aa3c,0x222222,1,0xc68c5a);g.rotation.x=-Math.PI/2;g.position.set(-5,.6,-6);W.add(g);
  g=new T.Group();bx(g,2.5,.5,1,0x8a5a2b,0,.3,0);co(g,1,3,0xffffff,0,2.2,0).scale.z=.2;g.position.set(8,0,-28);A(g,{k:"bt",x0:8});A(sp(W,.6,0xff6f91,0,1,0),{k:"ball",x0:8,z0:5});
  A(bx(W,200,.12,.8,0xffffff,0,.3,-19.5),{k:"wv"})}
 if(id=="F"){for(i=0;i<8;i++)A(sp(W,.12,0xfff3a0,0,0,0),{k:"o",x0:-14+i*4,h:2+i%3,a:i*.9}).position.set(-14+i*4,2,-8+(i%4)*5);
  for(i=0;i<3;i++)A(bx(W,.4,.2,.2,0x3b5a9a,0,6,0),{k:"f",a:i*2,r:12+i*3,h:7});
  for(i=0;i<2;i++){g=mk("R");g.position.set(-9+i*18,0,10);A(g,{k:"h",x0:-9+i*18,z0:10,a:i*2})}}
 if(id=="T"){for(i=0;i<5;i++)ped(i,-30+i*14,-5.5+(i%2)*-13,12);A(car(0xd9534f),{k:"car",x0:0,z0:-12,s:5});A(car(0x3b82c4),{k:"car",x0:60,z0:-14,s:-4});
  for(i=0;i<4;i++)A(sp(W,.25,0x888888,-8+i*4,.3,-6),{k:"pg",a:i})}}

/* ===== Story flow ===== */
function card(t){var c=$("card");c.innerHTML=t;c.className="on"}
function hud(){$("hud").innerHTML='<b>'+esc(S.name)+'</b> <span class="tag">'+S.br.n+'</span><br><span class="tag">'+U.mom(Math.min(S.i+1,N),N)+'</span> <span class="tag">'+U.age+' '+age().toFixed(1)+'</span><div style="margin-top:6px">'+bars()+'</div>'}
function box(h){$("dbox").innerHTML=h;$("dlg").style.display="flex"}
function say(sp,txt,cb,code){spk=code||"";box((sp?'<b>'+esc(sp)+'</b><br>':'')+txt+'<div class="res">'+U.cont+'</div>');adv=cb}
function moment(){var id=ORD[S.i],e=E[id],d=D[id];adv=null;spk="";$("dlg").style.display="none";
 card('<div><small>'+U.mom(S.i+1,N)+'</small><br><b>'+U.STG[e[0]]+'</b><br>'+U.SCN[e[1]]+'</div>');
 build(e[1],e[0]);ambient(e[1]);cast(d[0]);ap=null;ct=12;hud();
 setTimeout(function(){$("card").className="";
  say("",e[2],function(){var sp=d[1]=="*";ct=9;say(sp?S.name+" "+U.think:U.NM[d[1]],sp?"<i>"+d[2]+"</i>":U.q[0]+d[2]+U.q[1],choices,sp?"":d[1])})},2000)}
function choices(){var e=E[ORD[S.i]],h='<b>'+U.ask+'</b>';spk="";for(var j=3;j<e.length;j++)h+='<button class="btn" onclick="pick('+j+')">'+e[j][0]+'</button>';box(h);adv=null}
function reply(c,ids,cb){if(!ids.length)return cb();var x=ids.shift();say(U.NM[x],U.q[0]+RP[x][c]+U.q[1],function(){reply(c,ids,cb)},x)}
function pop(a){var p=$("pop");p.textContent=U.pop[a];p.className="on";setTimeout(function(){p.className=""},1400)}
function pick(j){var id=ORD[S.i],e=E[id],c=e[j],dl=[],t=clk.getElapsedTime(),b=0,bk="j";
 c[1].replace(/([hjlmb])(-?\d+)/g,function(x,k,v){v=+v;S[k]=cl(S[k]+v);dl.push(U.K[k]+" "+(v>0?"+":"")+v);if(Math.abs(v)>Math.abs(b)){b=v;bk=k}return x});
 var cat=b<0?2:bk=="m"?1:0,an=b<0?"cower":{m:"zoom",b:"bark",l:"nuzzle",h:"nap",j:S.turn%2?"spin":"hop"}[bk];
 S.log.push([age(),e[2]+" → "+c[0]]);S.turn++;ap={t:t,k:an};ct=8.5;
 chars.forEach(function(q){q.userData.hop=t});hud();pop(an);
 var d=D[id],ids=d[0].split("");if(d[1]!="*"&&ids.indexOf(d[1])>0){ids.splice(ids.indexOf(d[1]),1);ids.unshift(d[1])}ids=ids.slice(0,3);
 say(S.name+": "+c[0],c[2]+'<br><span class="tag">'+dl.join(" · ")+'</span>',function(){reply(cat,ids,function(){S.i++;if(S.i>=N||(S.h<=0&&S.turn>=10))finish();else moment()})})}
function loop(){requestAnimationFrame(loop);if(!go)return;
 var t=clk.getElapsedTime(),mv=0,p=dg.position;
 chars.forEach(function(g,i){var u=g.userData,h=u.hop?t-u.hop:9,sk=u.c==spk;g.position.y=h<1.6?Math.abs(Math.sin(h*6))*.9:Math.sin(t*3+i)*.06;
  if(u.arm)u.arm.forEach(function(a,n){a.rotation.z=sk?(n?-1:1)*(1.2+Math.sin(t*9+n)*.4):(n?-1:1)*(.08+Math.sin(t*2+i)*.04)});else g.rotation.x=sk?Math.sin(t*14)*.1:0});
 amb.forEach(function(g){var u=g.userData,a=u.a||0,k=u.k,q=g.position;
  if(k=="w"||k=="r"){var ph=t*(k=="r"?.9:.35)+a;q.x=u.x0+Math.sin(ph)*u.R;q.z=u.z0;g.rotation.y=Math.cos(ph)>0?1.57:-1.57;q.y=Math.abs(Math.sin(t*(k=="r"?9:5)+a))*.12}
  else if(k=="b"){q.set(Math.cos(t*.5+a)*u.r,2.5+Math.sin(t*2+a)*.8,Math.sin(t*.5+a)*u.r);g.rotation.z=Math.sin(t*20)*.8}
  else if(k=="c")q.x=u.x0+Math.sin(t*1.2+a)*3;
  else if(k=="f"){q.set(Math.cos(t*.4+a)*u.r,u.h+Math.sin(t*3+a)*.5,Math.sin(t*.4+a)*u.r);g.rotation.y=-t*.4-a;g.rotation.z=Math.sin(t*12)*.3}
  else if(k=="o"){q.y=u.h+Math.sin(t*1.5+a)*.8;q.x=u.x0+Math.sin(t*.7+a)*1.5;g.scale.setScalar(.6+Math.abs(Math.sin(t*2+a)))}
  else if(k=="h"){var z=t*.6+a;q.set(u.x0+Math.cos(z)*3,Math.abs(Math.sin(t*4+a))*.7,u.z0+Math.sin(z)*3);g.rotation.y=-z}
  else if(k=="car"){q.x=((t*u.s+u.x0)%120+120)%120-60;q.z=u.z0;g.rotation.y=u.s>0?0:Math.PI}
  else if(k=="bt"){q.y=Math.sin(t*1.5)*.15;q.x=u.x0+Math.sin(t*.3)*2}
  else if(k=="ball")q.set(u.x0+Math.sin(t*.8)*3,Math.abs(Math.sin(t*3))*1.6+.4,u.z0);
  else if(k=="pg")g.rotation.x=Math.sin(t*6+a)>.6?.6:0;
  else if(k=="wv")q.z=-19.5+Math.sin(t*.9)*.8;
  else if(k=="cl")q.x=((t*.8+u.x0+80)%160+160)%160-80});
 p.set(0,Math.sin(t*2.5)*.04,0);dg.rotation.set(0,0,0);dg.scale.set(1,1,1);
 if(ap){var u=t-ap.t,k=ap.k;if(u>2.6)ap=null;
  else if(k=="hop"){p.y=Math.abs(Math.sin(u*7))*1.1;mv=1}
  else if(k=="spin"){dg.rotation.y=u*5;p.y=Math.abs(Math.sin(u*5))*.4;mv=1}
  else if(k=="zoom"){var a=u*2.4;p.set(2.2*Math.sin(a),0,2.2*(1-Math.cos(a)));dg.rotation.y=Math.atan2(Math.cos(a),Math.sin(a));mv=1}
  else if(k=="bark")dg.rotation.x=-.6*(Math.sin(u*6)>0?1:0);
  else if(k=="nuzzle"){var q=chars[0];if(q){var dx=q.position.x,dz=q.position.z,l=Math.hypot(dx,dz),s=Math.sin(u/2.6*Math.PI)*3.2;p.set(dx/l*s,0,dz/l*s);dg.rotation.y=Math.atan2(dx,dz);mv=u<1.3?1:0}else dg.rotation.x=-.45}
  else if(k=="nap"){dg.rotation.z=1.3;p.y=.7}
  else{dg.scale.y=.75;dg.rotation.x=.2;p.x=Math.sin(u*30)*.06}}
 legs.forEach(function(g,i){g.rotation.x=mv?Math.sin(t*12+(i%2?0:Math.PI))*.7:0});
 tail.rotation.y=Math.sin(t*(mv?14:6))*.6;
 cr+=(ct-cr)*.04;var th=1.1+.4*Math.sin(t*.2);cam.position.set(cr*Math.sin(th),1+4.8*cr/12,cr*Math.cos(th));cam.lookAt(0,1.6,0);
 rd.render(sc,cam)}
function finish(){go=0;$("dlg").style.display="none";$("game").style.display="none";$("app").style.display="block";
 var life=S.turn>=N?S.br.life+(S.h-50)/15:age();life=Math.max(4,Math.round(life*10)/10);
 var sco=Math.round(S.h+S.j*1.2+S.l*1.5+S.b*.8-S.m*.5+life*8),t=U.ti[0];
 if(S.m>=70)t=U.ti[1];else if(S.l>=85)t=U.ti[2];else if(S.b>=85)t=U.ti[3];else if(S.j>=85)t=U.ti[4];else if(S.h>=85)t=U.ti[5];else if(S.m<=15&&S.l>=60)t=U.ti[6];
 var bh=U.bh[S.m>=60?0:S.m>=35?1:2];
 var h='<h1>🌈 '+esc(S.name)+' '+U.pass+'</h1><p class="sub">'+U.sur(S.br.n,life.toFixed(1))+'</p><div class="panel center"><p class="sub" style="margin:0">'+U.score+'</p><p class="big">'+sco+'</p><h2>'+t+'</h2><p class="res">'+esc(U.sum(S.name,bh,S.l>=60,S.b>=60,S.j>=60))+'</p>'+bars()+'</div><div class="panel"><b>'+U.story+'</b><ul class="log">';
 S.log.forEach(function(l){h+='<li><span class="tag">'+U.age+' '+l[0].toFixed(1)+'</span> '+esc(l[1])+'</li>'});
 $("app").innerHTML=h+'</ul></div><button class="btn go" onclick="start()">'+U.again+'</button>';scrollTo(0,0)}
